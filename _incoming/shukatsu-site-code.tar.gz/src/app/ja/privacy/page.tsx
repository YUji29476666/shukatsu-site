import { SimplePage } from "@/components/SimplePage";

export const metadata = { title: "プライバシーポリシー" };

export default function Privacy() {
  return <SimplePage title="プライバシーポリシー" />;
}
