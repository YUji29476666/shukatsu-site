import { SimplePage } from "@/components/SimplePage";

export const metadata = { title: "初めての方へ" };

export default function About() {
  return (
    <SimplePage
      title="初めての方へ"
      headings={[
        { text: "このサイトについて" },
        { text: "こんな人に" },
        { text: "使い方" },
        { text: "情報の確かめ方" },
        { id: "operator", text: "運営について" },
      ]}
    />
  );
}
