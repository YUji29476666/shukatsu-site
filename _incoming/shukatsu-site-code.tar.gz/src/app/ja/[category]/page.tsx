import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArticleCard } from "@/components/ArticleCard";
import { Breadcrumb } from "@/components/Breadcrumb";
import { categories } from "@/data/categories";
import { getCategory, mustArticle } from "@/lib/content";

export const dynamicParams = false;
export function generateStaticParams() {
  return categories.map((c) => ({ category: c.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ category: string }> }): Promise<Metadata> {
  const c = getCategory((await params).category);
  return { title: c?.name };
}

// カテゴリページ：中カテゴリを見出しにして記事カードを並べる（データから自動）
export default async function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
  const c = getCategory((await params).category);
  if (!c) notFound();
  const showHeadings = c.sections.length > 1 || !!c.features;
  return (
    <div className="mx-auto max-w-6xl px-5">
      <Breadcrumb items={[{ name: c.name }]} />
      <header className="pb-8 pt-4">
        <h1 className="text-3xl font-bold tracking-tight">{c.name}</h1>
        <p className="mt-2 text-sub">{c.tagline}</p>
        {showHeadings && (
          <nav aria-label="このカテゴリの見出し" className="mt-6 flex flex-wrap gap-2">
            {c.sections.map((s) => (
              <a key={s.id} href={`#${s.id}`} className="inline-flex min-h-11 items-center rounded-full border border-line bg-white px-4 text-sm hover:border-navy">
                {s.name}
              </a>
            ))}
            {c.features && (
              <a href="#popular" className="inline-flex min-h-11 items-center rounded-full border border-line bg-white px-4 text-sm hover:border-navy">
                {c.features.name}
              </a>
            )}
          </nav>
        )}
      </header>
      {c.sections.map((s) => (
        <section key={s.id} id={s.id} aria-labelledby={showHeadings ? `${s.id}-h` : undefined} className="scroll-mt-24 py-6">
          {showHeadings && (
            <h2 id={`${s.id}-h`} className="mb-5 border-l-4 border-navy pl-3 text-xl font-bold">
              {s.name}
            </h2>
          )}
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {s.articles.map((slug) => (
              <ArticleCard key={slug} a={mustArticle(slug)} />
            ))}
          </div>
        </section>
      ))}
      {c.features && (
        <section id="popular" aria-labelledby="popular-h" className="scroll-mt-24 py-6">
          <h2 id="popular-h" className="mb-1 border-l-4 border-navy pl-3 text-xl font-bold">
            {c.features.name}
          </h2>
          <p className="mb-5 text-sm text-sub">ほかのカテゴリの記事から、ボスキャリの準備によく読まれているものを紹介しています。</p>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {c.features.articles.map((slug) => (
              <ArticleCard key={slug} a={mustArticle(slug)} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
