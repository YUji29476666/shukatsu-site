import { SimplePage } from "@/components/SimplePage";

export const metadata = { title: "お問い合わせ・誤りの報告" };

export default function Contact() {
  return <SimplePage title="お問い合わせ・誤りの報告" note="お問い合わせと誤りの報告のフォームは準備中です。" />;
}
