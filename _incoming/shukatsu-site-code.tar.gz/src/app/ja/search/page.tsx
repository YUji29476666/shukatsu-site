import { Breadcrumb } from "@/components/Breadcrumb";
import { articles } from "@/data/articles";
import { articleUrl, getCategory, sectionOf } from "@/lib/content";

export const metadata = { title: "検索" };

// 静的サイトなので、全記事の一覧を出しておき、小さなスクリプトで絞り込む
const script = `
(() => {
  // 画面の組み立て（hydration）が終わってから動かす。入力は document で受ける
  const run = () => {
    const input = document.getElementById('search-q');
    const count = document.getElementById('search-count');
    if (!input || !count) return;
    const q = input.value.trim().toLowerCase();
    let n = 0;
    document.querySelectorAll('[data-text]').forEach((li) => { const hit = !q || li.dataset.text.includes(q); li.hidden = !hit; if (hit) n++; });
    count.textContent = q ? '「' + input.value.trim() + '」の記事：' + n + '件' : '全記事：' + n + '件';
  };
  document.addEventListener('input', (e) => { if (e.target.id === 'search-q') run(); });
  const start = () => setTimeout(() => {
    const input = document.getElementById('search-q');
    if (input && !input.value) input.value = new URLSearchParams(location.search).get('q') || '';
    run();
  }, 50);
  if (document.readyState === 'complete') start(); else window.addEventListener('load', start);
})();
`;

export default function SearchPage() {
  return (
    <div className="mx-auto max-w-3xl px-5">
      <Breadcrumb items={[{ name: "検索" }]} />
      <h1 className="pt-4 text-3xl font-bold tracking-tight">記事を探す</h1>
      <form role="search" action="/ja/search/" className="mt-6">
        <label htmlFor="search-q" className="sr-only">
          キーワード
        </label>
        <input id="search-q" name="q" placeholder="キーワードを入力" className="min-h-12 w-full rounded-2xl border border-line bg-white px-4 text-base outline-none focus:border-navy" />
      </form>
      <p id="search-count" aria-live="polite" className="mt-4 text-sm text-sub" />
      <ul className="mt-2 divide-y divide-line">
        {articles.map((a) => {
          const c = getCategory(a.category);
          const s = sectionOf(a);
          const text = [a.title, c?.name, s?.name].join(" ").toLowerCase();
          return (
            <li key={a.slug} data-text={text}>
              <a href={articleUrl(a)} className="flex min-h-12 flex-col justify-center py-3 hover:text-navy">
                <span className="font-bold">{a.title}</span>
                <span className="text-xs text-sub">
                  {c?.name}
                  {s && c && c.sections.length > 1 ? ` › ${s.name}` : ""}
                </span>
              </a>
            </li>
          );
        })}
      </ul>
      <script dangerouslySetInnerHTML={{ __html: script }} />
    </div>
  );
}
