export const metadata = { title: "English" };

export default function English() {
  return (
    <div lang="en" className="mx-auto max-w-3xl px-5 py-20 text-center">
      <h1 className="text-2xl font-bold">English version coming soon</h1>
      <p className="mt-3 text-sub">英語版は準備中です。</p>
      <a href="/ja/" className="mt-6 inline-block underline">
        日本語版へ戻る
      </a>
    </div>
  );
}
